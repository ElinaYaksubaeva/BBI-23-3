﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_7_1
{
    using System;
    using System.Text.RegularExpressions;
    abstract class Cross
    {
        protected string lastname_;
        protected int group_;
        protected string trener_;


        protected double rez_;
        public double rez => rez_;
        public Cross(string lastname, int group, string trener, double rez)
        {
            lastname_ = lastname;
            group_ = group;
            trener_ = trener;
            rez_ = rez;
        }
        public virtual void Print()
        {
            Console.WriteLine(
            "Фамилия: {0} \t Группа: {1} \t Тренер: {2} \t Результат: {3:f2} ",
            lastname_, group_, trener_);
        }
    }
    class Sto : Cross
    {
        public Sto(string lastname, int group, string trener, double rez) : base(lastname, group, trener, rez)
        {

        }
        public override void Print()
        {
            Console.WriteLine(
            "Фамилия: {0} \t Группа: {1} \t Тренер: {2} \t Результат: {3:f2} ",
            lastname_, group_, trener_, rez_);
        }
    }
    class Five : Cross
    {
        public Five(string lastname, int group, string trener, double rez) : base(lastname, group, trener, rez)
        {

        }
        public override void Print()
        {
            Console.WriteLine(
            "Фамилия: {0} \t Группа: {1} \t Тренер: {2} \t Результат: {3:f2} ",
            lastname_, group_, trener_, rez_);
        }

    }

    class Program
    {
        static void Main()
        {
            Five[] five = new Five[5]
            {
            new Five("Леденцова", 5, "Симочкина", 54.3),
                new Five("Лидова\t", 1, "Ситко\t", 61.3),
                new Five("Архипова", 4, "Метелкина", 55.9),
                new Five("Любвина ", 6, "Носова\t", 53.5),
                new Five("Рыкина\t", 2, "Калинина", 60.1)

            };
            Sto[] sto = new Sto[5]
           {
            new Sto("Леденцова", 5, "Симочкина", 22.4),
                new Sto("Лидова\t", 1, "Ситко\t", 19.3),
                new Sto("Архипова", 4, "Метелкина", 19.9),
                new Sto("Любвина ", 6, "Носова\t", 18.2),
                new Sto("Рыкина\t", 2, "Калинина", 25.7)

           };


            static void SortByNorm(Cross[] five)
            {
                for (int i = 0; i < five.Length - 1; i++)
                {
                    for (int j = i + 1; j < five.Length; j++)
                    {
                        if (five[j].rez < five[i].rez)
                        {
                            Cross temp = five[j];
                            five[j] = five[i];
                            five[i] = temp;
                        }
                    }
                }
            }
            SortByNorm(five);
            SortByNorm(sto);

            Console.WriteLine("500 метров : ");
            Console.WriteLine();
            for (int i = 0; i < 5; i++)
            {
                five[i].Print();
            }
            Console.WriteLine();
            Console.WriteLine("100 метров : ");

            Console.WriteLine();
            for (int i = 0; i < 5; i++)
            {
                sto[i].Print();
            }
        }
    }
}
