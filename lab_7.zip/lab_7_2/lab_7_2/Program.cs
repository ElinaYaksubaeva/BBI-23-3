﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_7_2
{
    using System;
    using System.Security.Cryptography;

    class People
    {
        protected string lastname_;
        private double math_;
        private double phi_;
        private double rus_;
        private double average_;
        public double average => average_;

        public People(string lastname, double x, double y, double z)
        {
            lastname_ = lastname;
            math_ = x;
            phi_ = y;
            rus_ = z;
            if (math_ > 2 && rus_ > 2 && phi_ > 2)
            {
                average_ = (math_ + phi_ + rus_) / 3;
            }
            else
            {
                average_ = 0;
            }
        }
        public virtual void Print()
        {
            Console.WriteLine("Фамилия: {0}\t Средний балл: {1:f2}", lastname_, average);
        }
    }
    class Student : People
    {
        private static int _id;
        private readonly int ID;
        public Student(string famile, double x, double y, double z) : base(famile, x, y, z)
        {
            _id++;
            ID = _id;
        }
        public override void Print()
        {
            Console.WriteLine("Фамилия: {0}\t Средний балл: {1:f2}\t ID: {2}", lastname_, average, ID);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student[] cl = new Student[5];
            cl[0] = new Student("Ермолаев", 3, 2, 5);
            cl[1] = new Student("Воронцов", 5, 5, 5);
            cl[2] = new Student("Кличко\t", 5, 4, 3);
            cl[3] = new Student("Лодов\t", 4, 4, 3);
            cl[4] = new Student("Воробьев", 5, 3, 3);

            static void SortBySred(People[] cl)
            {
                for (int i = 0; i < cl.Length - 1; i++)
                {
                    for (int j = i + 1; j < cl.Length; j++)
                    {
                        if (cl[j].average > cl[i].average)
                        {
                            People temp = cl[j];
                            cl[j] = cl[i];
                            cl[i] = temp;
                        }
                    }
                }
            }

            SortBySred(cl);
            Console.WriteLine("Список учащихся:");

            for (int i = 0; i < 5; i++)
            {
                cl[i].Print();
            }


            Console.WriteLine();
            Console.WriteLine("Список учащихся, успешно сдавших экзамены:");
            for (int i = 0; i < 5; i++)
            {
                if (cl[i].average != 0)
                {
                    cl[i].Print();
                }
            }
        }
    }
}
