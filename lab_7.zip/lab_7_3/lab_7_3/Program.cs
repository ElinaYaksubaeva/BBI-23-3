﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_7_3
{
    using System;
    using System.Drawing;
    using System.Reflection;
    using System.Text.RegularExpressions;

    class FootBall
    {
        private protected string team_;
        private int point_;
        protected string gender_;

        public int point => point_;
        public FootBall(string team, int point, string gender)
        {
            team_ = team;
            point_ = point;
            gender_ = gender;
        }
        public virtual void Printinf()
        {
            Console.WriteLine(
            " команда {0} \t очки {1}", team_, point_);
        }
    }
    class WomanTeam : FootBall
    {
        public WomanTeam(string team, int point, string gender) : base(team, point, gender)
        {
            gender_ = "Женская: ";
        }
        public override void Printinf()
        {
            Console.WriteLine(" {0} команда {1} \t очки {2}", gender_, team_, point);
        }

    }
    class MenTeam : FootBall
    {
        public MenTeam(string team, int point, string gender) : base(team, point, gender)
        {
            gender_ = "Мужская: ";

        }
        public override void Printinf()
        {
            Console.WriteLine(" {0} команда {1} \t очки {2}", gender_, team_, point);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            MenTeam[] groupmen = new MenTeam[]
                {
            new MenTeam("Динамо\t", 15, " "),
            new MenTeam("Ростов\t", 13, " "),
            new MenTeam("ЦСКА", 10, " "),
            new MenTeam("Спартак", 11, " "),
            new MenTeam("Анжи\t\t", 18, " "),
            new MenTeam("Локомотив", 7, " "),
            new MenTeam("Волгарь\t", 16, " "),
            new MenTeam("Реал Мадрид\t", 13, " "),
            new MenTeam("Зенит", 8, " "),
            new MenTeam("Барселона\t", 18, " "),
            new MenTeam("Ливерпуль", 7, " "),
            new MenTeam("Челси", 5, " "),
                };
            WomanTeam[] groupwomen = new WomanTeam[]
                {
            new WomanTeam ("Факел", 10, " "),
            new WomanTeam("Крылья Советов", 12, " "),
            new WomanTeam("Манчестер Сити", 11, " "),
            new WomanTeam("Ювентус\t", 13, " "),
            new WomanTeam("Торпедо\t", 18, " "),
            new WomanTeam("Бавария", 7, " "),
            new WomanTeam("Краснодар\t", 11, " "),
            new WomanTeam("Галатасарай", 7, " "),
            new WomanTeam("Ротор", 9, " "),
            new WomanTeam("Арсенал\t", 11, " "),
            new WomanTeam("Фенербахче\t", 14, " "),
            new WomanTeam("Милан", 8, " "),
                };
            static void SortByTeam(FootBall[] group1)
            {
                for (int i = 0; i < group1.Length; i++)
                {
                    for (int j = i + 1; j < group1.Length; j++)
                    {
                        if (group1[i].point < group1[j].point)
                        {
                            FootBall tewmp = group1[j];
                            group1[j] = group1[i];
                            group1[i] = tewmp;
                        }
                    }
                }
            }
            SortByTeam(groupwomen);
            SortByTeam(groupmen);

            FootBall[] rez = new FootBall[12];

            for (int i = 0; i < 6; i++)
            {
                rez[i] = groupmen[i];
            }

            for (int i = 0; i < 6; i++)
            {
                rez[i + 6] = groupwomen[i];
            }
            SortByTeam(rez);
            Console.WriteLine();
            Console.WriteLine("Окончательный список команд: ");

            for (int i = 0; i < 6; i++)
            {
                rez[i].Printinf();
            }
            for (int i = 6; i < 12; i++)
            {
                rez[i].Printinf();
            }
        }
    }
}
