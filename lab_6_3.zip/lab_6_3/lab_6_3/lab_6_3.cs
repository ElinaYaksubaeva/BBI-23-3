﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_6_3
{
    using System;
    using System.Drawing;
    using System.Text.RegularExpressions;

    struct FootBall
    {
        private string team_;
        private int points_;
        public int points => points_;
        public FootBall(string team, int points)
        {
            team_ = team;
            points_ = points;
        }
        public void Printinf()
        {
            Console.WriteLine(
            "команда {0} \t\t очки {1}", team_, points_);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            FootBall[] group1 = new FootBall[]
                {
            new FootBall ("Динамо\t", 11),
            new FootBall("Ростов\t", 17),
            new FootBall("ЦСКА\t", 9),
            new FootBall("Спартак", 10),
            new FootBall("Анжи\t", 15),
            new FootBall("Локомотив", 6),
            new FootBall("Волгарь", 13),
            new FootBall("Реал Мадрид", 12),
            new FootBall("Зенит\t", 8),
            new FootBall("Барселона", 14),
            new FootBall("Ливерпуль", 7),
            new FootBall("Челси\t", 6),
                };
            FootBall[] group2 = new FootBall[]
                {
            new FootBall ("Факел\t", 9),
            new FootBall("Крылья Советов", 13),
            new FootBall("Манчестер Сити", 11),
            new FootBall("Ювентус", 18),
            new FootBall("Торпедо", 17),
            new FootBall("Бавария", 6),
            new FootBall("Краснодар", 10),
            new FootBall("Галатасарай", 7),
            new FootBall("Ротор\t", 8),
            new FootBall("Арсенал", 14),
            new FootBall("Фенербахче", 12),
            new FootBall("Милан\t", 6),
                };
            static void SortByTeam(FootBall[] group1)
            {
                for (int i = 0; i < group1.Length; i++)
                {
                    for (int j = i + 1; j < group1.Length; j++)
                    {
                        if (group1[i].points < group1[j].points)
                        {
                            FootBall tewmp = group1[j];
                            group1[j] = group1[i];
                            group1[i] = tewmp;
                        }
                    }
                }
            }
            SortByTeam(group2);
            SortByTeam(group1);

            for (int i = 0; i < 12; i++)
            {
                group1[i].Printinf();
            }
            Console.WriteLine();
            for (int i = 0; i < 12; i++)
            {
                group2[i].Printinf();
            }
            FootBall[] rez = new FootBall[12];

            for (int i = 0; i < 6; i++)
            {
                rez[i] = group1[i];
            }

            for (int i = 0; i < 6; i++)
            {
                rez[i + 6] = group2[i];
            }
            SortByTeam(rez);
            Console.WriteLine();
            Console.WriteLine("Окончательный список команд: ");

            for (int i = 0; i < 12; i++)
            {
                rez[i].Printinf();
            }
        }
    }
}
